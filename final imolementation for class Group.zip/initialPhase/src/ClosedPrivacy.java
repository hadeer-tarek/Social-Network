
public class ClosedPrivacy extends GroupPrivacy {

	public IGroup group;
	public User u;
  
  public void setAllowedUser(User user) {
	  for( int i = 0 ; i < group.groupMembers.size() ; i++){
		  group.users.add(group.groupMembers.elementAt(i));
		  // users is array list contain  all users in this group till now
	  }
	  //check if this user exist in group or not
	  
	  for(int i = 0 ; i < group.groupMembers.size() ; i++){
		  if(user == group.groupMembers.get(i)){
			  for(int j = 0 ; j < u.userFriend.size() ; j++){
			       group.users.add(u.userFriend.elementAt(j));
			      // users become contains all users in group and their friends 
			  }
		  }
		  else {
			  group.addMember(user);
		  }
	  }
	  
  }

}
