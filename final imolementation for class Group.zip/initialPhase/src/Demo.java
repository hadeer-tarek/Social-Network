
import java.sql.SQLException;
import java.util.Scanner;


public class Demo 
{
	public static void main (String[] args) throws ClassNotFoundException, SQLException
	{   Scanner intinput=new Scanner(System.in);
		Scanner input=new Scanner(System.in);
		String type;
		int choose=0;
		System.out.print("\t \t welcome to our Social network \n");
		System.out.println("1-Create New user \n 2-login   \n 3-check connection \n Enter number");
		choose=intinput.nextInt();
		if(choose==1)
		{
		System.out.print("please , Enter your type -p or n- ");
		type=input.nextLine();
		System.out.print(type+"\n");
		 if(type.equals("p"))
		 {   System.out.print("primary\n");
		 PrimaryUser pUser=new PrimaryUser();
			 pUser.signup(pUser);
			 
		 }else if(type.equals("n"))
		   {   System.out.print("normal \n");
			 NormalUser nUser=new  NormalUser();
			 nUser.signup(nUser);
		   }
		
		
		}
		if(choose==2)
		  { 
		     	System.out.println(" ");
		    	String check;
			   Scanner in = new Scanner (System.in);
			   System.out.println("Are you primary or normal user ? p-n");
			   check=in.next();
			   if (check.equals("n"))
			    {
				   NormalUser LoginUser=new NormalUser();
				   User.signIn(LoginUser);
			    } else  if(check.equals("p"))
			            {
			    	        PrimaryUser LoginUser=new PrimaryUser();
			    	        User.signIn(LoginUser);
			            }
			
		  }
		if(choose==3)
		 {

			GroupModel g = new GroupModel();
			 g.createGroup();
			
		 }
		
	}

}
