
import java.util.Scanner;
import java.util.Vector;

public class Group extends IGroup {

  public static String title;
  public static int ID;
  public static String coverPicture;

 // public users : Map <IUser,Role> ;

    public GroupModel myGroupModel;
    
    public void setID(int id){
    	ID = id;
    }
    public void setTitle(String t){
    	title = t;
    }
    
    public void setCover(String c){
    	coverPicture = c;
    }
    
    public int getID(){
    	return ID;
    }
    public String getTitle(){
    	return title;
    }
    public String getcoverPicture(){
    	return coverPicture;
    }

  public void addMember(User user)
  {
  }

  public void removeMember() 
  {
  }

  public void setRole() 
  {
  }

}