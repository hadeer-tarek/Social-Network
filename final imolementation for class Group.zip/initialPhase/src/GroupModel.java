import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.Vector;
import java.sql.*;

public class GroupModel {

	public Group myGroup = new Group();

	public Vector<Group> allGroup = new Vector ();

	// connection with table group in SQL
	public static void getGroupConn()throws ClassNotFoundException, SQLException {
		try
        {
		Class.forName("com.mysql.jdbc.Driver");

		Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/SocialNetwork", "root", "");
		
		PreparedStatement statment=con.prepareStatement("SELECT * FROM `group`");
		ResultSet result=statment.executeQuery();
		//execute query
		System.out.println("ID" + " \t" + "Group Name" 
    			+ " \t" + "cover Picture "+ " \t" + "Group Privacy");
    	
		    while(result.next())
		     {
		    	System.out.println(result.getInt(1) + " \t" + result.getString(2) 
		    			+ " \t" + result.getString(3)+ "\t \t" + result.getString(4));
		    	
		     }
        }catch(Exception Ex)
        {
            System.out.println("Error" + Ex);
        }
	}
	public void createGroup() throws ClassNotFoundException, SQLException {
		System.out
				.println("if you want to creat group enter ( Y ) if not enter ( N )");
		Scanner input = new Scanner(System.in);
		String choise = input.next();
		if (choise.equals("Y") || choise.equals("y")) {
			System.out.println(" enter group ID ");
			myGroup.ID = input.nextInt();
			System.out.println(" enter group name ");
			myGroup.title = input.next();
			System.out.println(" enter cover picture of group ");
			myGroup.coverPicture = input.next();
			while (myGroup.title.isEmpty()) {
				System.out.println("You must  enter group name ");
				myGroup.title = input.next();
			}
				GroupModel.getGroupConn();
				GroupModel.insertGroup(myGroup.ID ,myGroup.title ,myGroup.coverPicture);
                allGroup.add(myGroup);
			}
			 
	     else if (choise.equals("N") || choise.equals("n")) {
			System.out.println("tayeb -_-");
		}
	}
	public static void insertGroup(int id , String name , String cov) {

		 PreparedStatement statment = null  ; 
		 String Query = ("INSERT * INTO  `group` (ID , Title , Cover)" + " VALUES"  + id + name + cov );
		  
		  try
	        {
			  statment.executeUpdate(Query);
	            System.out.println("Record is inserted into Group table!");
	        }
	        catch(Exception Ex)
	        {
	            System.out.print(Ex);
	        }
	}
	public void deleteGroup() {
		System.out
				.println("if you want to delete group enter ( Y ) if not enter ( N )");
		Scanner input = new Scanner(System.in);
		String choise = input.next();
		if (choise == "Y" || choise == "y") {
			System.out.println(" enter group name ");
			myGroup.title = input.next();
			while (myGroup.title.isEmpty()) {
				System.out.println("You must  enter group name ");
				myGroup.title = input.nextLine();
			}
			allGroup.remove(myGroup);
		} else if (choise == "N" || choise == "n") {
			System.out.println("tayeb -_-");
		}
	}
	
	public void updateGroup() {
		Scanner input = new Scanner(System.in);
		System.out.println(" Update Group ");
		System.out.print(" Please Enter Group Name : ");
		String groupName = input.next();
		boolean isStringExists = false;
		isStringExists = allGroup.contains(groupName);
		if (isStringExists == false) {
		System.out.println(" This Group Wasn't Found !! ");
		} else if (allGroup.equals(groupName)) {
		myGroup.title = groupName;
		System.out.println(" Your Group Name Updated Successfully ");

		//myGroup.newTitle = input.next();
		//myGroup.title = myGroup.newTitle;
		}
		}
		public void getGroup() {
		Scanner input = new Scanner(System.in);
		System.out.print(" Enter Group Name : ");
		String groupName = input.next();
		boolean isStringExists = false;
		isStringExists = allGroup.contains(groupName);
		if (isStringExists == false) {
		System.out.println(" This Group Wasn't Found !! ");
		} else {
		System.out.println(myGroup.ID +myGroup.title + myGroup.coverPicture);
		}
		}

}