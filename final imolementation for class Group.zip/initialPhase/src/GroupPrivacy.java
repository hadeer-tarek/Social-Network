

import java.util.Vector;
import java.util.ArrayList;

public class GroupPrivacy {

// public List <IUser> allowedUsers;

    public IGroup myIGroup;

  public void getAllowedMembers(IGroup group) {
	  
  }

}