

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;

public class IGroup {

  public GroupPrivacy privacy;

    public Vector  <User> groupMembers;
    
    ArrayList <User> users = new ArrayList<User> ();
    
    public GroupPrivacy myGroupPrivacy;
    public Vector  hasA;

	public void addMember(User user) {
  	  System.out.println("if you want join this group enter join ");
  	  Scanner input = new Scanner (System.in);
  	  String word = input.nextLine();
  	  if(word == "join"){
  		groupMembers.add(user);
  	  }
  	  else {
  		  System.out.println("thanks for visiting us ");
  	  }
    }

  public void removeMember(User user) {
	  System.out.println("if you want remove this group enter remove ");
  	  Scanner input = new Scanner (System.in);
  	  String word = input.nextLine();
  	  if(word == "remove"){
  		groupMembers.remove(user);
  	  }
  	  else {
  		  System.out.println("thanks for visiting us ");
  	  }
  }

  public void setRole(String role) {
  }

  public void setPrivacy() {
  }

}