
import java.util.ArrayList;

public abstract  class IPage extends User
{   
	 protected boolean checkLike=false;
     private String pageName;	
	 private  ArrayList<User> usersLikePage = new ArrayList<User> ();
	 
	 
	  IPage()
	   {
		  pageName="  ";
		  usersLikePage=null;
		  checkLike=false;
	   }

	  public  abstract  void likeAPage(User user,String Like,IPage LikedPage); 
	
	   public void setpageName(String name)
	    {
		   pageName=name;
	    }
	   public void setUsers(User user)
	    {
		   usersLikePage.add(user);
	    }
	   public void setLike(boolean done)
	    {
		   checkLike=done;
	    }
	   public ArrayList<User> getUsersLikePage()
	   {
		   return usersLikePage ;
	   }
	   public String getPageName()
	    {
		   return  pageName;
	    }
	   public boolean getCheckLike()
	   {
		   return checkLike;
	   }
	  
	 
 
}
