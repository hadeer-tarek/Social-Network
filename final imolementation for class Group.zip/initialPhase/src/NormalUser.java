

import java.util.Scanner;


public class NormalUser extends User 
{

	public User us;

	public NormalUser()
	{
		firstName = null ;
    	lastName = null ;
    	Email = null ;
    	Password = null ;
    	Age = 0;
    	Phone =(double) 0 ;
    	Gender = " E" ;
    	userName = "Empty  " ;
    	userType="normal ";
    	friendCounter=0;
    	active=false;

	}
	/**
	 * sign up for normal user
	 * @param nUser
	 */

	public void signup(NormalUser nUser)
	{
		Scanner sinput=new Scanner(System.in);
		Scanner input=new Scanner(System.in);
        String choose;
	     nUser.userType="Normal";
		System.out.print("Enter your frist name:");
		nUser.firstName=sinput.nextLine();;
		System.out.print("Enter your last name:");
		nUser.lastName=sinput.nextLine();
		System.out.print("pless  Enter your email :");
		nUser.Email=sinput.nextLine();
		while(nUser.Email.isEmpty())
		{
			System.out.println("You must enter your email !!!! ");
			nUser.Email=sinput.nextLine();
		}

		System.out.print("pless  Enter your password:");
		nUser.Password=sinput.nextLine();
		while(nUser.Password.isEmpty())
		{
			System.out.println("You must enter your password !!!! ");
			nUser.Password=sinput.nextLine();
		}
		System.out.print("pless  Enter your user name :");
		nUser.userName=sinput.nextLine();
		while(nUser.userName.isEmpty())
		{
			System.out.println("You must enter your user name !!!! ");
			nUser.userName=sinput.nextLine();
		}
		System.out.print("pless  Enter your gender:");
		nUser.Gender=sinput.nextLine();
		System.out.print("pless  Enter your age:");
		nUser.Age=input.nextInt();
		System.out.print("pless  Enter your phone:");
		nUser.Phone=input.nextDouble();
		nUser.friendCounter=0;
		nUser.active=true;
		nusers.add(nUser);
		 Display(nUser);
		 System.out.println("\n Do you want to send friend request ?!\n yes-no ");
		 choose=sinput.nextLine();
		 if(choose.equals("y")||choose.equals("Y"))
		 {
			 NormalUser l= new NormalUser();
			 System.out.println("Sending the request ");
		 nUser.sendFriendRequest(l);
		 }else  if(choose.equals("n")||choose.equals("n"))
		         {
			        System.out.println("ok !! enjoy ^_^ ");
		         }

		 
		

		 
	}
	
	
		
	
	  public  NormalUser getCurrentActiveUser(NormalUser nUser)
	  {
		  if(nUser.active  ==false)
		  {
			  nUser= new NormalUser();
		  }
		  return nUser;
	  }
	public boolean checkUserRequest(NormalUser l)
	{
    	return false;
    	}

	public boolean sendFriendRequest(NormalUser q )
	  {
	  //check if the request sent before or not
	  // ..userName check if the request exist or Not
	  //uModel.checkUserRequest(q.userName);
  	System.out.println("\nSearching in the database ");
  	//You should create DataBase to search in it 
	  if(uModel.checkUserRequest(q)==false)
	  {
	  System.out.println(" Not allowed to send this request ,,, this request is already exist ");
	  return false;
	  }
	  else
	  {
	  System.out.println(" Request is sent ");
	  return true;
	  }

	  }

	public void Display(NormalUser  nUser)
	 {
		System.out.print("\n welcome "+nUser.getFirstName()+nUser.getLastName()+"\n You are "+nUser.getuserType()+"user \n Your Email is: "+nUser.getEmail()+"\nYour age : "+nUser.getAge());
	 }


	public void checkCurrentFriendsCount(NormalUser n) 
	 {
		if(n.userType == "Normal")
		{
			if(n.friendCounter < 3999)
		    n.friendCounter++;
			
			else
			System.out.println("can not add this friend ");
		}
		else 
			 n.friendCounter++;
		
		}
		
	
	@Override
	public void signup() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean sendFriendRequest(User q) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public User getCurrentActiveUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

}
