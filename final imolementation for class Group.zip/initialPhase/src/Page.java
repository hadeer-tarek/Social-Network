

public class Page extends IPage  
{
	



   public void likeAPage(User user,String Like,IPage LikedPage)
   {
	    if(Like.equals("like")&&LikedPage.checkLike==false)
	     {
	    	LikedPage.getUsersLikePage().add(user);
	    	
	    	LikedPage.setLike(true);
	    
	     }else 
	          {
	    	       System.out.println("\n \t \t You already like the page !!!");
	          }
   }

@Override
public void signup() {
	// TODO Auto-generated method stub
	
}

@Override
public User getCurrentActiveUser(User user) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public boolean sendFriendRequest(User q) {
	// TODO Auto-generated method stub
	return false;
}

}
