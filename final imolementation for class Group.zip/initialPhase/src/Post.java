
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author Nada
 */
public class Post {
    
    public List<User> currentAllowed;
    Scanner in = new Scanner ( System.in);
    String postContent;
    String updatedPost;

    public Vector  hasA;
    //public Vector  hasA;

  public void writePost() 
  {
      System.out.println(" Update Your Status :D ");
      postContent = in.nextLine();
      
  }

}
