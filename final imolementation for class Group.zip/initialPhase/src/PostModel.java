


import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author Nada
 */
public class PostModel extends Post{
    public Post p;
    public Vector <Post> allPosts;
    Scanner in = new Scanner ( System.in);
    
  public void createPost() 
  {
      p.writePost();
      System.out.println(" To Publish Your Post Choose ' Post ' ");
      String Choice = in.nextLine();
      
      if(Choice.equals("Post"))
      {
          System.out.println(" Post Content \n " + postContent);
          allPosts.add(p);
      }
  }

  public void deletePost() 
  {
      System.out.println(" To Delete Your Post Choose ' Delete ' ");
      String Choice = in.nextLine();
      if ( Choice.equals("Delete"))
      {
          
          allPosts.remove(p);
      }
  }

  public void getPost() 
  {
      System.out.println(" Post Content \n " + p.postContent);
      
  }

  public void updatePost() 
  {
      System.out.println(" To Update Your Post Choose ' Update ' ");
      String Choice = in.nextLine();
      
      if(Choice.equals("Update"))
      {
          p.updatedPost = in.nextLine();
          postContent = updatedPost;
          allPosts.add(p);
      }
  }
}
