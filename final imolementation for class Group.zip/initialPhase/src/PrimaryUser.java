


import java.util.Scanner;

public class PrimaryUser  extends User
{

    public PrimaryUser()
	{
		firstName = null ;
    	lastName = null ;
    	Email = null ;
    	Password = null ;
    	Age = 0;
    	Phone =(double) 0 ;
    	Gender = " " ;
    	userName = "  " ;
    	userType="Primary ";
    	friendCounter=0;

	}
	/**
	 * Sign up for primary User
	 * @param pUser
	 */

	public void signup(PrimaryUser   pUser)
	{
		Scanner sinput=new Scanner(System.in);
		Scanner input=new Scanner(System.in);
	    pUser.userType="Primary";
		System.out.print("Enter your frist name: ");
		pUser.firstName=sinput.nextLine();;
		System.out.print("Enter your last name: ");
		pUser.lastName=sinput.nextLine();
		System.out.print("pless  Enter your email :");
		pUser.Email=sinput.nextLine();
		while(pUser.Email.isEmpty())
		{
			System.out.println("You must enter your email !!!! ");
			pUser.Email=sinput.nextLine();
		}
		System.out.print("pless  Enter your password:");
		pUser.Password=sinput.nextLine();
		while(pUser.Password.isEmpty())
		{
			System.out.println("You must enter your password !!!! ");
			pUser.Password=sinput.nextLine();
		}
		System.out.print("pless  Enter your user name :");
		pUser.userName=sinput.nextLine();
		while(pUser.userName.isEmpty())
		{
			System.out.println("You must enter your username !!!! ");
			pUser.userName=sinput.nextLine();
		}
		System.out.print("pless  Enter your gender:");
		pUser.Gender=sinput.nextLine();
		System.out.print("pless  Enter your age:");
		pUser.Age=input.nextInt();
		System.out.print("pless  Enter your phone:");
		pUser.Phone=input.nextDouble();
		pUser.friendCounter=0;
        pUser.active=true;
		 pusers.add(pUser);
		 Display(pUser);
		 sendFriendRequest(pUser );
		 payByCredit( pUser );
		
		 
		

	}

	// Get current active user function
	public  PrimaryUser getCurrentActiveUser(PrimaryUser user)
	  {
		  if( user.active==false)
		  {
			  user= new PrimaryUser();
		  }
		  return user;
	  }
	public boolean checkUserRequest(PrimaryUser l) 
	   {
    	return false;
    	}
	public boolean sendFriendRequest(PrimaryUser q )
	  {
	  //check if the request sent before or not
	  // ..userName check if the request exist or Not
	  //uModel.checkUserRequest(q.userName);
  	System.out.println("\nSearching in the database ");
  	//You should create DataBase to search in it 
	  if(uModel.checkUserRequest(q)==false)
	  {
	  System.out.println(" Not allowed to send this request ,,, this request is already exist ");
	  return false;
	  }
	  else
	  {
	  System.out.println(" Request is sent ");
	  return true;
	  }

	  }

	public void Display(PrimaryUser   pUser)
	 {
		System.out.print("\n welcome "+pUser.getFirstName()+pUser.getLastName()+"\n You are "+pUser.getuserType()+"user \n"+"Your Email is: "+pUser.getEmail()+"\nYour age : "+pUser.getAge());
	 }




	  protected  String accountName;
	  protected  String accountPassword;
	  protected  double  creditCardNumber;

	  public void payByCredit(PrimaryUser   pUser ) 
	  { 
			Scanner sinput=new Scanner(System.in);
		  System.out.println("\nEnter your account number :");
		  pUser.accountName=sinput.nextLine();
		  System.out.println("Enter your creditcard number : ");
		  pUser.creditCardNumber=sinput.nextInt();
		  System.out.println("Enter your password : ");
		  pUser.accountPassword=sinput.nextLine();
			while(pUser.accountPassword.isEmpty()||pUser.accountPassword.length()<9)
			{
				System.out.println("You must enter your password ,password must greater then 10 !!!! ");
				pUser.accountPassword=sinput.nextLine();
			}

		  System.out.println("\t \t congratulation , welcome "+pUser.getUserName()+"  to our social network \n \t \t  have fun ^_^ =D");
		  
		  
	  }
	@Override
	public void signup() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean sendFriendRequest(User q) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public User getCurrentActiveUser(User user) {
		// TODO Auto-generated method stub
		return null;
	}

}
