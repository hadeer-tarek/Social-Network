


import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author Nada
 */
public abstract class PrivacyPost extends Post {

  public Post myPost;
  public User user;
  public PostModel pModel;
  public PrivatePost Private;
  public PublicPost Public ;
  Scanner in = new Scanner ( System.in);
 // protected Vector <User> userFriend ;

  public void writePost() 
  {
      System.out.println(" Update Your Status :D ");
      postContent = in.nextLine();
  }

  public void setAllowedMembers() 
  {
        if(user.userFriend.contains(user.getUserName())){
            
          pModel.getPost(); 
      }
        else
            System.out.println(" This Member Is Not Allowed To See Post !");
   }
  
  public void PrivacyPost(Post p) 
  {
      System.out.println(" Choose Your Post Privacy :D \n For Private Post Choose ' Private ' \n "
                        + " For Public Post Choose ' Public ' \n Enter Your Choice : ");
      String Choice = in.nextLine();
      
      if(Choice.equals("Private"))
      {
          Private.setAllowedMembers() ;
      }
      
      if(Choice.equals("Public")){
          Public.setAllowedMembers();
      }
  }    
}
