


/**
 *
 * @author Nada
 */
public class PrivatePost extends PrivacyPost
{

  public void setAllowedMembers() 
  {
      if(user.userFriend.contains(user.getUserName())){
            
          pModel.getPost(); 
      }
      else
            System.out.println(" This Member Is Not Allowed To See Post !");
  }

}


