

public class PublicPost extends PrivacyPost 
{    public UserModel uMod;
     public void setAllowedMembers() 
  {     
      if(uMod.signedUser.contains(user.getUserName()))
          pModel.getPost();    
  }

}
