

public class PublicPrivacy extends GroupPrivacy {

	  public Integer importance;

	  public UserModel users ;
	  public User allUsers ;
	  public IGroup group ;
	  
	  public void setAllowedUser(User user)
	  {
		  System.out.println("any one can see this group ");
		  
			  users.signedUser.add(user);
			// ana me4 3arfa elmafroud a2ool ezzay en el user dh ye2dar ye4of group lw 7d 3ndoo fekra y2ool w ana azbtha
		  
	  }
	  
	  public void setImportance()
	  {
	  }

	  public void getImportance() 
	  {
	  }

	}