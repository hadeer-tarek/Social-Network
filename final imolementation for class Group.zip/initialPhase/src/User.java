

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;


public abstract class User extends UserData 
{

	  private static UserData user=null;
	  public static  UserModel uModel = null  ;
	  protected User u;
	  protected NormalUser us;
	  protected Vector <User> userFriend;
	  
	  
	  /**
	     *
	     * @param null is default value of firstName , lastName , Email , Password and Phone
	     * @param 10 is the default age of user
	     * @param male is the default Gender of user
	     * @param  new user is the default name of user
	     */
		public User()
		    {
		    	firstName = null ;
		    	lastName = null ;
		    	Email = null ;
		    	Password = null ;
		    	Age = 0;
		    	Phone = (double) 0 ;
		    	Gender = " " ;
		    	userName = "  " ;
		    	userType=" ";
		    	friendCounter=0;
		    	active=false;
		    }

	    /**
	     * constructs  a userData with firstName ,lastName ,Email ,password , age , phone , gender and the user name of the user
	     * @param firstName the first name of the user
	     * @param lastName the last name of the user
	     * @param Email the email account of the user
	     * @param password the password of the account
	     * @param Age the age of the user
	     * @param phone the phone number of the user
	     * @param Gender the gender of the user (Mail/female)
	     * @param userName the name of the account
	     *  @param type the user type
	     */


		protected User ( String firstName,String lastName,String Email,String Password,int Age,
		            double Phone,String Gender, String userName,String type,double friendnum)
		{
		this.firstName =firstName;
		this.lastName =lastName;
		this.Email=Email;
		this.Password=Password;
		this. Age= Age;
		this. Phone= Phone;
		this.Gender=Gender;
		this.userName=userName;
		this.userType=type;
		this.friendCounter=friendnum;

		}
		
		  public abstract void signup();
		  public  abstract User getCurrentActiveUser(User user);

		  
		//public void signIn( String userName, String password) 
	   public static void signIn( User LoginUser) 
		  {
		   Scanner in = new Scanner (System.in);
	
		      //while ( true )
		//  {
		     System.out.print(" Please Enter Your Account User Name : ");
		       LoginUser.userName = in.nextLine();
		      System.out.print(" Please Enter Your Account Password : ");
		      LoginUser.Password= in.nextLine();
		      if( uModel.checkUserdata(LoginUser.userName, LoginUser.Password) == true ){
		      //if(uModel.getUserName().equals(userName) && uModel.getPassword().equals(password)){
		         System.out.println(" Succeeded To Login :D ");
		         LoginUser.active=true;
		         //break;
		      }
		      else
		      {
		          System.out.println(" User name or password is incottect ! ");
		       //   continue ;
		      }
		 // }
		}

		  public void signOut(User user) 
		  {
		     user.active=false;
			  System.exit(0);
		  }

		  public void Edit( String userName ,String password) 
		  {

		      Scanner in = new Scanner (System.in);
		      while(true){
		      System.out.print(" Please Enter Your Account Password : ");
		      password = in.nextLine();
		      System.out.print(" Please Enter Your Account User Name : ");
		      userName = in.nextLine();

		      if(uModel.checkUserdata(userName , password)== true){
		          System.out.print(" Please Enter Your New Password : ");
		          String newPassword = in.nextLine();
		          while(true){
		            System.out.print(" Please Enter Confirm Password : ");
		            String confirmNewPassword = in.nextLine();
		            if(newPassword.equals(confirmNewPassword)){
		            password = newPassword;
		            System.out.println(" Your Password Have Been Changed Successfully :D ");
		            break;
		          }
		          else
		          {
		             System.out.println(" Confirm Password Isn't Correct ! ");

		          }
		        }
		          break;
		      }

		      else{
		         System.out.println(" The Password You Entered Is Not Correct ! ");
		         continue;
		      }
		    }
		  }
			    public void addFriend(NormalUser q){
			    	//NormalUser q;
			    	if (u.sendFriendRequest(q) == false)
			    	{
			    		q.checkCurrentFriendsCount(q);
			    		

			    	}

			  }
			    public void changeUserType(User chageUser) 
			    {
			    	if(chageUser.userType.equals("Normal ") )
			    	{
			    		chageUser.userType.equals("Primary ");
			    		// payByCredit( chageUser);
			   		}
			   		else if(chageUser.userType.equals("primary ") )
			   		{
			   			chageUser.userType.equals("Normal ");
			   		}
			   		else 
			   		{
			   			System.out.println("wrong type ");
			   		}

			    }


			    public boolean checkData(String mail , String pass) {
			    	if ( Email == mail && Password == pass)
					  {
						  System.out.println("please wait few seconds ");
						  return true ;
					  }
				  else {
					  System.out.println("Email or password does not correct pleas try again ! ");
					  return false;
			    }
			    }

			    public abstract boolean sendFriendRequest(User q );

			 // modify at the data of the account


		   public void modifyAccountData(String newMail , int newAge , double newPhone , String newGender )
		{
		        ArrayList<User> users = new ArrayList<User> ();
		        Scanner input=new Scanner(System.in);
		        System.out.println("Enter the user name");
		        String name =input.nextLine();
		        boolean isStringExists=false;
		        // check if this user exist or not
		        isStringExists = users .contains(name);
		        if(isStringExists== false)
		            {
		                System.out.println("this user is not exist ,try again !!!");
		            }
		        else
		            {
		                     if(users.equals(name))
							  {
								  user.Email=newMail;
								  user.Age= newAge;
								  user.Phone=newPhone;
								  user.Gender=newGender;
							  }
							  else
								  return;
		            }

		        uModel.saveUserData();
		        
		}
		
	}