

import java.util.ArrayList;

public class UserData {

		protected String firstName;
		  protected String lastName;
		  protected String Email;
		  protected String Password;
		 // private Image profilePic;
		  protected int Age;
		  protected Double Phone;
		  protected String Gender;
		  protected String userName;
	      protected String userType;
	      protected  double friendCounter=0;
	      protected boolean active=false;
	      protected  ArrayList<PrimaryUser> pusers = new ArrayList<PrimaryUser> ();
	      protected  ArrayList<NormalUser> nusers = new ArrayList<NormalUser> ();


	     /**
	     * default constructors
	     * @param null is default value of firstName , lastName , Email , Password ,
	     * @param null is default value of Gender , userName and Phone
	     * @param 0 is the default age of user
	     */

	   /* public void UserData() {
	    	firstName = null ;
	    	lastName = null ;
	    	Email = null ;
	    	Password = null ;
	    	Age = 0;
	    	Phone = null ;
	    	Gender = " " ;
	    	userName = "  " ;

	    }

	     /**
	     * constructs  a userData with firstName ,lastName ,Email ,password , age , phone , gender and the user name of the user
	     * @param firstName the first name of the user
	     * @param lastName the last name of the user
	     * @param Email the email account of the user
	     * @param password the password of the account
         * @param Age the age of the user
         * @param phone the phone number of the user
         * @param Gender the gender of the user (Mail/female)
         * @param userName the name of the account
	     */
	/*	public userData ( String firstName,String lastName,String Email,String Password,int Age,
		                 double Phone,String Gender, String userName , boolean IsN)
		{
		    this.firstName =firstName;
		    this.lastName =lastName;
		    this.Email=Email;
		    this.Password=Password;
		    this. Age= Age;
		    this. Phone= Phone;
		    this.Gender=Gender;
		    this.userName=userName;
		    IsNormal = IsN ;
		
		}
		*/
		/**
		*
		* @param n is the user name to set
		*/

	    public void setUserName( String n) {
	  	  userName = n;
	    }


	    /**
	    *
	    * @param a is the age of user to set
	    */
	    public void setAge( int a) {
	  	  Age = a;
	    }


	    /**
	    *
	    * @param E is the Email of user to set
	    */
	    public void setEmail( String E) {
	  	  Email = E;
	    }

   /**
   *
   * @param FN is the first name to set
   */
	    public void setFirstName( String FN) {
	  	  firstName = FN;
	    }
	    /**
	     *
	     * @param pass is the password to set
	     */

	    public void setPassword(String pass) {
	    	Password=pass;

	    }



		/**
		*
		* @param n is the last name to set
		*/


	    public void setLastName( String LN) {
	  	  lastName = LN;
	    }

		/**
		*
		* @param g is the gender to set
		*/
	    public void setGender( String g) {
	    	Gender =g;
	    }
	    
	    /**
		*
		* @param type is the user type
		*/
	    public void setUserType( String type)
	    {
	      userType=type;
	    }

	    /**
	    *
	    * @param phone is the user phone number
	    */


	    	    public void setUserPhone( double phone)
	    	    {
	    	    	Phone =phone;
	    	    }

	    /**
	    *
	    * @return current user name
	    */
	    public String getUserName() {
	  	  return userName;
	    }

	    /**
	    *
	    * @return age of the user
	    */
	    public int getAge() {
	    return Age;
	    }
	    /**
	    *
	    * @return current user email
	    */

	    public String getEmail() {
	    return Email;
	    }

	    /**
	    *
	    * @return current user first name
	    */
	    public String getFirstName() {
	  	  return firstName;
	    }
	    /**
	    *
	    * @return current user password
	    */
	    public String getPassword() {
	    return Password ;
	    }
	    /**
	    *
	    * @return current user last name
	    */
	    public String getLastName() {
	  	  return lastName;
	    }
	    /**
	    *
	    * @return current user gender
	    */

	    public String getGender() {
	    return Gender ;
	    }


	    /**
	    *
	    * @return current user type
	    */

	    public String getuserType()
	    {
	    return userType ;
	    }


	    /**
	    *
	    * @return current user phone
	    */

	    public double getuserPhone()
	    {
	    return Phone ;
	    }


}
