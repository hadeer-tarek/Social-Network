
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public abstract class UserModel extends User 
  {
 
	public static boolean checkConnection()
	 //class exist in the  mysql jdk
	{	//System.out.println("Iam  here ");	
		try{
		//	System.out.println("check try");
		//create connection
		  Class.forName("com.mysql.jdbc.Driver");
          Connection  con = DriverManager.getConnection
        		  ("jdbc:mysql://localhost:3306/�socialnetwork" , "root" , "");
       //creating query
		PreparedStatement statment=con.prepareStatement("select * from User");
		ResultSet result=statment.executeQuery();
		System.out.println("ID \t First name\t second name\t email\t     password\t    "
				+ " username \t    age\t  phone \t gender \t userType \t numFriend \t active");
		//execute query
		   while(result.next())
		     {
		    	
		        System.out.println(result.getString(1)+"\t  "+result.getString(2)+"  \t"+result.getString(3)
		        	       +"\t\t"+result.getString(4)+"\t"+result.getString(5)+"\t"+result.getString(6)
		        	       +"\t"+result.getString(7)+"\t"+result.getString(8)+"\t"+result.getString(9)
		        	       +"\t"+result.getString(10)+"\t"+result.getString(11)+"\t"+result.getString(12)
		        			          );
		     }
		     return true;
		       } catch(Exception Error)
			           {
		    	   System.err.println("Exception: " + Error);
		    	   return false;
			           }
	}
	
	private String userID;
	public Vector <User> signedUser  ;
	
	public UserModel(String firstName, String lastName,   String Email,
			         String Password,int Age,double Phone,String Gender,
		             String userName) 
	{
		super(firstName, lastName, Email, Password, Age, Phone, Gender, userName, userName, Phone);
		// TODO Auto-generated constructor stub
	}

 
	public boolean checkUserdata( String userName , String password ) 
	     {
		  return false;
		  }
	
    public void saveUserData() {
		System.out.println("data is saved ");
	  }
    
    
    public boolean checkUserRequest(User q) {
    	return false;
    	}
	
	
	public void DBuserModel(User signUser ) {
		
		signedUser.add(signUser);
		
		for(int i = 0 ; i < signedUser.size() ; i++)
		   System.out.println( "ID  " + i + "  " + signUser );
  	}

	@Override
	public void signup() {
		// TODO Auto-generated method stub
		
	}

}