


public class UserPost extends Post {

  public void writePost() {
      System.out.println(" Update Your Status :D ");
      postContent = in.nextLine();
  }

}
