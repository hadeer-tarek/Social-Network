
public abstract class User extends userData {


  //public abstract void sendFriendRequest();
  //public abstract void addFriend();

  public void signIn( String userName, String password) {
	  
  }

  public void signOut() {
  }

  public void Edit( String userName, String password) {
  }

  public void uploadPic() {
  }

  public void share() {
  }

  public boolean signup( String firstName,  String lastName ,  String Email,  Integer Age,
		  String Password, Double Phone,  String Gender,  String userName) {
  return false;
  }

  public void like() {
  }

  public void writeComment() {
  }

  public void groupUserView() {
  }

  public void changeUserType() {
  }

  public boolean checkData() {
  return false;
  }

 public void getCurrentActiveUser() {
  }


  public void joinGroup(String groupName) {
  }

  public void modifyAccountData() {
  }

  public void editData() {
  }

}