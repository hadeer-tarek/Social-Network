public class normalUser extends User {


  public void checkCurrentFriendsCount() {
  }

}
