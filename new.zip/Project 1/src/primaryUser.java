public class primaryUser extends User {

  private String accountName;
  private Integer accountPassword;
  public String creditCardNumber;

  public void payByCredit() {
  }

}
