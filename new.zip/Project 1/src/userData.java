public class userData {
	 private String firstName;
	  private String lastName;
	  private String Email;
	  private String Password;
	 // private Image profilePic;
	  private Integer Age;
	  private Double Phone;
	  private String Gender;
	  private String userName;
	    public User user;
	    public User myUser;
	    public User Instance;

    /**
     * 
     * @param null is default value of firstName , lastName , Email , Password and Phone 
     * @param 10 is the default age of user 
     * @param male is the default Gender of user
     * @param  new user is the default name of user
     */
	    public void UserData() {
	    	firstName = null ;
	    	lastName = null ;
	    	Email = null ;
	    	Password = null ;
	    	Age = 10 ;
	    	Phone = null ;
	    	Gender = " male " ;
	    	userName = " new user " ;
	    	
	    }
	    /**
	    *
	    * @param n is the user name to set
	    */
	    public void setUserName(String n) {

	    userName = n;
	    }

	    /**
	    *
	    * @param a is the age of user to set
	    */
  public void setAge( int a) {
	  Age = a;
  }

  /**
  *
  * @param a is the Email of user to set
  */
  public void setEmail( String E) {
	  Email = E;
  }

  /**
  *
  * @param n is the first name to set
  */
  public void setFirstName( String FN) {
	  firstName = FN;
  }

  public void setPassword(String pass) {
  }

  /**
  *
  * @param n is the last name to set
  */
  public void setLastName( String LN) {
	  lastName = LN;
  }

  public void setGender( String g) {
  }

  /**
  *
  * @return current user name
  */
  public String getUserName() {
	  return userName;
  }
  /**
  *
  * @return current Age
  */
  public int getAge() {
  return Age;
  }

  /**
  *
  * @return current Email
  */
  public String getEmail() {
  return Email;
  }

  /**
  *
  * @return current first name
  */
  public String getFirstName() {
	  return firstName;
  }

  public String getPassword() {
  return null;
  }

  /**
  *
  * @return current last name
  */
  public String getLastName() {
	  return lastName;
  }

  public String getGender() {
  return null;
  }

}