import java.util.Vector;

public class userModel extends User {

  private String userID;

    public userData myuserData;
    public Vector  getUserD;

  public void saveUserData() {
  }

  public void DBuserModel( Integer ID) {
  }

  public boolean checkUserdata() {
  return false;
  }

}